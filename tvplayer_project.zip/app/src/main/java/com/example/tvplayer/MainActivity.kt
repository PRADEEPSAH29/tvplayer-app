package com.example.tvplayer

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.GridLayout
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.json.JSONArray

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private val CHANNEL_COUNT = 6

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("tv_prefs", Context.MODE_PRIVATE)

        val grid = findViewById<GridLayout>(R.id.grid)

        val channels = loadChannelsDefaultIfNeeded()

        for (i in 0 until CHANNEL_COUNT) {
            val channel = channels.optJSONObject(i)
            val btn = ImageButton(this)
            btn.layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8,8,8,8)
            }
            btn.scaleType = ImageButton.ScaleType.CENTER_CROP
            btn.adjustViewBounds = true
            btn.setBackgroundResource(0)

            val logo = channel.optString("logoUri", "")
            if (logo.isNotEmpty()) {
                Glide.with(this).load(logo).placeholder(R.drawable.ic_placeholder).into(btn)
            } else {
                btn.setImageResource(R.drawable.ic_placeholder)
            }

            val streamUrl = channel.optString("streamUrl", "")
            btn.setOnClickListener {
                if (streamUrl.isNotEmpty()) {
                    val intent = Intent(this, PlayerActivity::class.java)
                    intent.putExtra("streamUrl", streamUrl)
                    startActivity(intent)
                }
            }

            grid.addView(btn)
        }

        findViewById<View>(R.id.editButton).setOnClickListener {
            startActivity(Intent(this, EditChannelsActivity::class.java))
        }
    }

    private fun loadChannelsDefaultIfNeeded(): JSONArray {
        val saved = prefs.getString("channels_json", null)
        if (saved != null) {
            return JSONArray(saved)
        }
        val text = assets.open("channels.json").bufferedReader().use { it.readText() }
        prefs.edit().putString("channels_json", text).apply()
        return JSONArray(text)
    }
}
