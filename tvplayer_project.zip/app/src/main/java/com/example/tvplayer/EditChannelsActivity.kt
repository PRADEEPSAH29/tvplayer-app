package com.example.tvplayer

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class EditChannelsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private val CHANNEL_COUNT = 6

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_channels)

        prefs = getSharedPreferences("tv_prefs", Context.MODE_PRIVATE)

        val container = findViewById<LinearLayout>(R.id.container)

        val channels = loadChannels()

        val nameFields = mutableListOf<EditText>()
        val logoFields = mutableListOf<EditText>()
        val streamFields = mutableListOf<EditText>()

        for (i in 0 until CHANNEL_COUNT) {
            val ch = channels.optJSONObject(i)
            val name = EditText(this)
            name.hint = "Channel name"
            name.setText(ch.optString("name"))
            container.addView(name)
            nameFields.add(name)

            val logo = EditText(this)
            logo.hint = "Logo image URL or drawable name (res/drawable)"
            logo.setText(ch.optString("logoUri"))
            container.addView(logo)
            logoFields.add(logo)

            val stream = EditText(this)
            stream.hint = "Stream URL (HLS/M3U8/MP4)"
            stream.setText(ch.optString("streamUrl"))
            container.addView(stream)
            streamFields.add(stream)
        }

        val saveBtn = Button(this)
        saveBtn.text = "Save"
        saveBtn.setOnClickListener {
            val arr = JSONArray()
            for (i in 0 until CHANNEL_COUNT) {
                val obj = JSONObject()
                obj.put("name", nameFields[i].text.toString())
                obj.put("logoUri", logoFields[i].text.toString())
                obj.put("streamUrl", streamFields[i].text.toString())
                arr.put(obj)
            }
            prefs.edit().putString("channels_json", arr.toString()).apply()
            finish()
        }
        container.addView(saveBtn)
    }

    private fun loadChannels(): JSONArray {
        val saved = prefs.getString("channels_json", null)
        if (saved != null) return JSONArray(saved)
        val text = assets.open("channels.json").bufferedReader().use { it.readText() }
        return JSONArray(text)
    }
}
